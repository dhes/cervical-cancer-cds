# Home - Cervical Cancer Screening CDS for OpenMRS v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://hopenahealth.com/fhir/cervical-cancer-cds/ImplementationGuide/hopena.cervical-cancer-cds | *Version*:0.1.0 |
| Draft as of 2026-03-17 | *Computable Name*:CervicalCancerCDS |

This implementation guide provides computable clinical decision support (CDS) for cervical cancer screening and treatment, implementing the [WHO guideline for screening and treatment of cervical pre-cancer lesions for cervical cancer prevention, 2nd edition (2021)](https://www.who.int/publications/i/item/9789240030824).

### Scope

This IG implements **Algorithm 5: HPV DNA primary screening with VIA triage** for both the general population of women and women living with HIV (WLHIV). It covers the full screening cascade:

* **Screening eligibility and scheduling** – age, sex, HIV status, screening interval
* **Triage** – VIA assessment of HPV-positive women
* **Treatment** – ablation eligibility checklist, modality selection
* **Follow-up** – post-treatment and post-triage-negative retesting, WLHIV double follow-up

### Target Platform

[OpenMRS](https://openmrs.org/) O3 Reference Application with the FHIR2 module, deployed in low- and middle-income countries (LMICs). The CDS artifacts are platform-agnostic FHIR R4 and CQL, usable with any FHIR-enabled system.

### Artifacts

This IG contains:

* **5 CQL libraries** implementing the clinical logic
* **4 PlanDefinition resources** defining ECA (Event-Condition-Action) rules
* **5 FHIR Library resources** wrapping the CQL for FHIR-based evaluation

See the [Artifacts](artifacts.md) page for the complete list.

### Technical Approach

Clinical logic is authored in [CQL (Clinical Quality Language)](https://cql.hl7.org/) and compiled to ELM for runtime evaluation. The CQL uses [CIEL](https://openconceptlab.org/orgs/CIEL/) terminology codes mapped to SNOMED CT, LOINC, and ICD-10, matching the OpenMRS concept dictionary.

The CDS follows [WHO SMART Guidelines L3](https://smart.who.int/) conventions: one CQL library per decision table, shared definitions in a common library, PlanDefinition resources for each decision rule.

### Dependencies

### IP Statements

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [CervicalCancerFollowUp](PlanDefinition-CervicalCancerFollowUp.md), [CervicalCancerScreening](PlanDefinition-CervicalCancerScreening.md), [CervicalCancerTreatment](PlanDefinition-CervicalCancerTreatment.md) and [CervicalCancerTriage](PlanDefinition-CervicalCancerTriage.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [ActionType](http://terminology.hl7.org/7.1.0/CodeSystem-action-type.html): [CervicalCancerFollowUp](PlanDefinition-CervicalCancerFollowUp.md), [CervicalCancerScreening](PlanDefinition-CervicalCancerScreening.md), [CervicalCancerTreatment](PlanDefinition-CervicalCancerTreatment.md) and [CervicalCancerTriage](PlanDefinition-CervicalCancerTriage.md)
* [LibraryType](http://terminology.hl7.org/7.1.0/CodeSystem-library-type.html): [CervicalCancerFollowUpDecision](Library-CervicalCancerFollowUpDecision.md), [CervicalCancerScreeningCommon](Library-CervicalCancerScreeningCommon.md), [CervicalCancerScreeningDecision](Library-CervicalCancerScreeningDecision.md), [CervicalCancerTreatmentDecision](Library-CervicalCancerTreatmentDecision.md) and [CervicalCancerTriageDecision](Library-CervicalCancerTriageDecision.md)
* [PlanDefinitionType](http://terminology.hl7.org/7.1.0/CodeSystem-plan-definition-type.html): [CervicalCancerFollowUp](PlanDefinition-CervicalCancerFollowUp.md), [CervicalCancerScreening](PlanDefinition-CervicalCancerScreening.md), [CervicalCancerTreatment](PlanDefinition-CervicalCancerTreatment.md) and [CervicalCancerTriage](PlanDefinition-CervicalCancerTriage.md)
* [UsageContextType](http://terminology.hl7.org/7.1.0/CodeSystem-usage-context-type.html): [CervicalCancerFollowUp](PlanDefinition-CervicalCancerFollowUp.md), [CervicalCancerScreening](PlanDefinition-CervicalCancerScreening.md), [CervicalCancerTreatment](PlanDefinition-CervicalCancerTreatment.md) and [CervicalCancerTriage](PlanDefinition-CervicalCancerTriage.md)


