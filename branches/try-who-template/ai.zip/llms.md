# hopena.cervical-cancer-cds#0.1.0: Cervical Cancer Screening CDS for OpenMRS

## Pages

* [Home](index.md)
* [Architecture](architecture.md)
* [Downloads](downloads.md)
* [Decision Tables](decision-tables.md)
* [Clinical Algorithm](algorithm.md)
* [Change Log](changes.md)
* [Testing](testing.md)
* [Artifacts Summary](artifacts.md)
* [Deployment Guide](deployment.md)
* [Algorithm 5: Purposive L2 — DMN Viewer](algorithm-5-hpv-via-purposive.md)
* [Algorithm 5: Textualist L2 — DMN Viewer](algorithm-5-hpv-via-textualist.md)
* [Decision Modeling](methodology.md)
* [Interpretation Register](interpretation-register.md)
* [License](license.md)

## Resources

### ImplementationGuides

* [Cervical Cancer Screening CDS for OpenMRS](index.md)

### Libraries

* [Cervical Cancer Follow-Up Decision Logic](Library-CervicalCancerFollowUpDecision.md)
* [Cervical Cancer Screening Common Definitions](Library-CervicalCancerScreeningCommon.md)
* [Cervical Cancer Screening Decision Logic](Library-CervicalCancerScreeningDecision.md)
* [Cervical Cancer Treatment Decision Logic](Library-CervicalCancerTreatmentDecision.md)
* [Cervical Cancer Triage Decision Logic](Library-CervicalCancerTriageDecision.md)

### PlanDefinitions

* [Cervical Cancer Follow-Up — Post-Treatment and Post-Triage Scheduling](PlanDefinition-CervicalCancerFollowUp.md)
* [Cervical Cancer Screening Eligibility and Cascade Routing](PlanDefinition-CervicalCancerScreening.md)
* [Cervical Cancer Treatment — Ablation Eligibility and Modality Selection](PlanDefinition-CervicalCancerTreatment.md)
* [Cervical Cancer Triage — HPV-Positive VIA Assessment](PlanDefinition-CervicalCancerTriage.md)
